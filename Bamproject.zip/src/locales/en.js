const english = {

  home:{
    events:'Events'
  },

  cartTemp: {
    cart:'Cart',
    tickets:'Tickets',
    fees:'Fees',
    eur: 'EUR',
    subtotal:'Subtotal',
    tax:'Tax',
    total:'Total',
    total_amount:'Total Amount',
    checkout:'CHECKOUT',
    msg:'Cras mattis consectetur purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur.',
    back:'Back',
  }
  
}

export default english;