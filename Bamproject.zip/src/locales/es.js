
const spanish = {
  cartTemp: {
    cart:'Carro',
    tickets:'Entradas',
    fees:'Tarifa',
    eur: 'EUR',
    subtotal:'Total parcial',
    tax:'Impuesto',
    total:'Total',
    total_amount:'Cantidad total',
    checkout:'VERIFICAR',
    msg:'Cras mattis consectetur purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur.',
    back:'atrás',
  }
}

export default spanish;