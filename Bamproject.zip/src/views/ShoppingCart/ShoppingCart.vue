<template>
<Cart />
</template>
<script>
import Cart from "../../components/cartModule/Cart.vue";
export default {
    name: 'ShoppingCart',
    components: {
        Cart
    },
}
</script>
