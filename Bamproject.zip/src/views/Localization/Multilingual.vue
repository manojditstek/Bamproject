<template>
<div>
    {{ $t('message.title') }}
</div>
</template>

<script>
export default {
    name: 'Multilingual'
}
</script>
