<template>
  <div>
    <!-- step 1 -->
    <div class="d-flex justify-content-between align-items-end header">
      <h2>
        <router-link to="/">Back to Home</router-link>
      </h2>
    </div>
    <!---->
    <div class="cardBodyWrapper bgLight">
      <div class="payDesc">
        <h1>Your tickets are in your Inbox</h1>
        <p>We sent you a confirmation mail together with your tickets. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh.</p>
        <div class="buttons">
          <button class="button btnGreen" @click="sendMail()">Resend Email</button>
          <button class="button btnDefault" @click="downloadTkt()">Download tickets</button>
        </div>
      </div>
    </div>
    <!---->
    <div class="cardBodyWrapper">
        <Loader />
      <div class="ticketDesc">
        <h2>Event Name</h2>
        <div class="eventDetails">
          <div class="eventInnerDetails">
            <div class="eventIcon">
              <i class="fa fa-calendar-o" aria-hidden="true"></i>
            </div>
            <div class="eventDesc">
              <label>23 June 2021</label>
              <label>08:30 pm - 11:30pm</label>
            </div>
          </div>
          <div class="eventInnerDetails">
            <div class="eventIcon">
              <i class="fa fa-map-marker" aria-hidden="true"></i>
            </div>
            <div class="eventDesc">
              <label>Venue Name</label>
              <label>08:30 pm - 11:30pm</label>
            </div>
          </div>
        </div>
        <div class="ticketCart">
         <table class="table">
          <thead>
            <tr>
              <th>{{tcktDetails.orderItem.length}}</th>
              <th></th>
              <th>{{tcktDetails.total}} {{currency}}</th>
            </tr>
          </thead>
          <tbody v-for="(ticket) in tcktDetails.orderItem" :key="ticket.id">
            <tr >
              <td>{{ticket.ticket.length}}</td>
              <td >{{ticket.ticket[0].ticketConfig.name}} <br> Discount Category</td>
              <td>{{ticket.ticket[0].ticketConfig.faceValue}} {{ticket.ticket[0].ticketConfig.currency}}</td>
            </tr>
          </tbody>
          <tfoot>
            <tr>
              <td colspan="2">Date: {{toDayDate}}</td>
              <td>Order ID: {{tcktDetails.id}}</td>
            </tr>
          </tfoot>
         </table>

        </div>
        <div class="ticketCartDesc">
          <h4>Hinweis </h4> 
          <p>Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nullam quis risus eget urna mollis ornare vel eu leo.</p>
        </div>
        <div class="footerActionBtn"><router-link to="/" class="button"><button type="button"> Back to Shop </button></router-link></div>
      </div>
    </div>
  </div>
</template>

<script>
import { computed,ref } from "vue";
import { useStore } from "vuex";
import moment from 'moment'
import Loader from '../../components/loader/Loader.vue'
import bam from '../../services/bamSdk'
export default {
  name: "DownloadTicket",
  components:{
      Loader
  },
  setup() {
    const store = useStore();
    const toDayDate = ref();
    toDayDate.value = moment().format(" DD MMM YYYY ")
    const tcktDetails = computed(() => {
      return store.state.createdOrder;
    });

    let orderID = computed(() => {
      return store.state.createdOrder;
    });

    let currency = computed(function () {
            return store.state.currency
        });

    async function downloadTkt() {
      await store.dispatch("downloadTicketPdf", {
        orderId: orderID.value.id
      });
    }
    async function sendMail(){
      await bam.order.sendOrderEmail({ id: orderID.value.id })
    }
    return {
      tcktDetails,
      downloadTkt,
      currency,
      toDayDate,
      sendMail
    };
  }
};
</script>
