/* Including headers file */
import router from "../router/";
import moment from "moment";
import bam from '../services/bamSdk'
import {saveStreamToFile} from 'bam-ticketing-sdk';
import download from "downloadjs";

/* end header */

/* This method used for multiple events */
export const getEvents = async ({commit}, dateRange) => {
    commit('loadingStatus', true)
    let startDateFormat = '';
    let endDateFormat = '';
    startDateFormat = moment(dateRange.start,'YYYY-MM-DD').toDate();
    endDateFormat = moment(dateRange.end,'YYYY-MM-DD').toDate();
    let dateRng = [startDateFormat,endDateFormat];
    if(dateRange){
        await bam.event.listEvents({
            with: {
                ticket_config: true,
                occurrence: true,
            },
            start_at:dateRng,
        }).then((response) => {
            if(response==''){
                let msg = {message:'Event Not found !'}
                commit('errorMsg', msg);
            }else{

                commit('errorMsg', null);
            }
            commit('setEvents', response)
            commit('loadingStatus', false)
        }).catch(response => {
            console.log(response);
            commit('errorMsg', response);
            commit('loadingStatus', false)
        });
    }else{
        await bam.event.listEvents({
            with: {
                ticket_config: true,
                occurrence: true,
            },
        }).then((response) => {
            commit('setEvents', response)
            commit('loadingStatus', false)
        }).catch(response => {
            console.log(response);
            commit('errorMsg', response);
            commit('loadingStatus', false)
        });
    }
}/* end multiple evets */


/* This method used for single event */
export const getEvent = async ({
    commit
}, id) => {
    commit('loadingStatus', true)
    await bam.event.getEvent({
        id: id
    }).then((response) => {
        commit('setEvent', response)
        commit('loadingStatus', false)
    }).catch(response => {
        commit('loadingStatus', false)
        console.log(response);
        commit('errorMsg', response);
    });
}
//end single event

/* This method used for single event with time slots  */
export const sigleEventWithTimeSlot = async ({commit}, data) => {
    commit('loadingStatus', true)
    await bam.event.getEvent({
        id: data.event_id
    }).then((response) => {
        commit('setEventWithTimeSlot', response)
        commit('setTimeSlots', data.timeSlot)
        commit('loadingStatus', false)
    }).catch(response => {
        commit('loadingStatus', false)
        console.log(response);
        commit('errorMsg', response);
    });
}
//end time slots evevnt


/* This method used for seated event */
export const workSpaceKey = async ({commit}) => {
    let organizer = await bam.account.getOrganizer({
        id: 'eventspace',
        fields: ['workspace']
    });
    commit('workSpaceKey', organizer)
}
// end seated event

/* This method used for recurring event*/
export const recurringEvent = async ({commit}, id) => {
    commit('loadingStatus', true)
    await bam.event.getEvent({id: id}).then((response) => {
        commit('setRecurringEvent', response)
        commit('loadingStatus', false)
    }).catch(response => {
        commit('loadingStatus', false)
        alert(`Data not found`);
        router.push('/')
        console.log(response);
        commit('errorMsg', response);
    });
}
// end recurring event



/* This method used for create order */
export const createOrder = async ({commit}, cartItem) => {
    // console.log('createdOrderItem=>', cartItem)
    commit('loadingStatus', true)
    await bam.order.createOrder({
        orderItem: cartItem.cartItems,
        format:cartItem.format
    }).then((response) => {
        commit('loadingStatus', false)
        commit('setCreateOrder', response)
        router.push('/user-kyc-form')
        }).catch(response => {
            console.log(response);
            commit('errorMsg', response);
            commit('loadingStatus', false)
        });
}
// end create order method

/* This method used for storing ticket holder information  */
export const ticketHolderInfo = async ({commit}, data) => {
    commit('loadingStatus', true)
    data.orderItem.forEach(async(element,i) => {
        await bam.order.createTicketHolder({id:element.ticket[0].id},
            {
                firstName: data.data.first_name[i],
                lastName: data.data.last_name[i],
                email: data.data.email[i],
                phone: data.data.phone[i],
            }
        )
        .then((response) => {
            commit('loadingStatus', false)
            router.push('/user-form')
        }).catch(response => {
            console.log(response);
            commit('errorMsg', response);
            commit('loadingStatus', false)
        })
    })
}
// end ticket holder information

/* This method used for storing order contact details  */
export const orderContact = async ({commit}, data) => {
    commit('loadingStatus', true)
    await bam.order.createOrderContact({ id: data.id }, 
        {
            first_name: data.data.first_name,
            last_name: data.data.last_name,
            phone: data.data.phone,
            email: data.data.email,
            billing_email: data.data.billing_email,
        }
    )
    .then((response) => {
        commit('loadingStatus', false)
    }).catch(response => {
        console.log(response);
        commit('errorMsg', response);
        commit('loadingStatus', false)
    });
}
// end order contact details


/* This method used for Payment module  */
export const paymentInitiate = async ({commit}, data) => {
    commit('loadingStatus', true)
    await bam.payment.createPaymentIntent({
        orderId: data.id,
        type: data.payMethod
    })
    .then(async (response) => {
        commit('paymentInitiate', response)
        commit('loadingStatus', false)
    }).catch(response => {
        console.log(response);
        commit('errorMsg', response);
        commit('loadingStatus', false)
    });
}
//end Payment module 

/* This method used for set timer  */
export const startTimer = async ({commit}) => {
    commit('timer');
}
//end set timer


/* This method used for download ticket  */
export const downloadTicketPdf = async ({commit}, data) => {
setTimeout(async () => {
    let ticket = await bam.order.downloadTickets({ id: data.orderId })
    console.log('ticketResp',ticket)
    saveByteArray([ticket], 'ticket.pdf'); 
    // await saveStreamToFile(ticket, 'ticket.pdf');
    var file = window.URL.createObjectURL(ticket);
        var a = document.createElement("a");
        a.href = file;
        a.download = "ticket.pdf" || "detailPDF";
        document.body.appendChild(a);
        a.click();
        // remove `a` following `Save As` dialog, 
        // `window` regains `focus`
        window.onfocus = function () {                     
          document.body.removeChild(a)
        }
}, 3000)
}
//end download ticket

/* This is helper method for downloading ticket  */
var saveByteArray = (function () {
    var a = document.createElement("a");
    document.body.appendChild(a);
    a.style = "display: none";
    return function (data, name) {
        var blob = new Blob([data], {type: "application/pdf"}),
        url = window.URL.createObjectURL(blob);
        a.href = url;
        a.download = name;
        a.click();
        window.URL.revokeObjectURL(url);
    };
}());
//end 





