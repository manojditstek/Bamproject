<template>
<div class="singleTicketTotalAmount d-flex">
    <TotalTicketCalculation />
    <div class="labelBtn">
        <BackButton :message="'back'" class="button" />
    </div>
</div>
<div class="cardBodyWrapper">
    <Loader />
    <div class="eventDiscountWrapper">
        <h2>{{ $t('cartTemp.cart') }}</h2>
        <div class="amountWrapper">
            <p>{{totalQuantity}} {{ $t('cartTemp.tickets') }} <span>{{totalPrice}}</span></p>
            <p>{{ $t('cartTemp.fees') }} <span>0.00 {{ $t('cartTemp.eur') }}</span></p>
        </div>
        <div class="amountWrapper">
            <p>{{ $t('cartTemp.subtotal') }} <span>{{ $t('cartTemp.eur') }}</span></p>
            <p>{{ $t('cartTemp.tax') }} (0%) <span>{{ $t('cartTemp.eur') }}</span></p>
        </div>
        <div class="totalAmountWrapper ">
            <p>{{ $t('cartTemp.total') }} <span>{{totalPrice}}</span></p>
        </div>
    </div>
</div>

<div class="ticketWrapper">
    <div class="ticketCategory d-flex" v-for=" item in cart.cartItems" :key="item.id">
        <div class="dateCol">
            <h2>{{item.quantity}}</h2>
        </div>
        <div class="detailsCol">
            <h2>{{item.name}}</h2>
            <p>
                {{item.eventName}}
            </p>
            <div class="priceWrap">
                {{item.totalPrice}} {{item.currency}}
            </div>
        </div>
        <div class="collapseArrow redBg" @click="removeFromCart(item)">
            <img src="assets/images/close-icon.svg" width="10" alt="image">
        </div>
    </div>
</div>

<div class="footerActionBtn">
    <button class="button" :class="totalQuantity==0?'disabled':''" :disabled="totalQuantity==0" @click="checkout">
        {{ $t('cartTemp.checkout') }}
    </button>
</div>

<div class="sloganText ">
    <p>{{ $t('cartTemp.msg') }}</p>
</div>
</template>

<script>
import {
    computed,
} from 'vue';
import {
    useStore
} from "vuex";
import {
    useRouter
} from "vue-router";
import TotalTicketCalculation from "./TotalTicketCalculation"
import Loader from '../loader/Loader'
import BackButton from '../backButton/BackButton'
export default {
    name: "Cart",
    components: {
        TotalTicketCalculation,
        Loader,
        BackButton
    },
    setup() {
        const store = useStore();
        const router = useRouter();

        let cart = computed(function () {
            return store.state.cart
        });

        let event = computed(function () {
            return store.state.event
        });

        let currency = computed(function () {
            return store.state.currency
        });

        const totalPrice = computed(() => {
            return store.state.cart.itemTotalAmount;
        });

        const totalQuantity = computed(() => {
            return store.state.cart.itemsTotalQuantity;
        });

        function removeFromCart(item, complete = true) {
            if (complete) {
                store.commit("removeCartItemComplete", item);
            } else {
                store.commit("removeCartItem", item);
            }
        }

        function checkout() {

            router.push({
                path: '/delivery-method'
            })
        }

        return {
            cart,
            totalPrice,
            totalQuantity,
            removeFromCart,
            currency,
            event,
            checkout,

        }
    }
}
</script>
